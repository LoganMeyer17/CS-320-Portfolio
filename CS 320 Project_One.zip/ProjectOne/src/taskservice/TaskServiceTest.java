/* Logan Meyer 10/11/2025 */
package taskservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {
    // add task
    @Test
    void addTask_addsWhenUnique() {
        TaskService svc = new TaskService();
        Task t = new Task("T1", "Name", "Desc");
        svc.addTask(t);
        assertEquals("T1", svc.getAll().get("T1").getTaskId());
    }

    @Test
    void addTask_rejectsDuplicateId() {
        TaskService svc = new TaskService();
        svc.addTask(new Task("T1", "A", "B"));
        assertThrows(IllegalArgumentException.class,
            () -> svc.addTask(new Task("T1", "X", "Y")));
    }

    @Test
    void addTask_rejectsNull() {
        TaskService svc = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> svc.addTask(null));
    }

    // delete task
    @Test
    void deleteTask_removesExisting() {
        TaskService svc = new TaskService();
        svc.addTask(new Task("T1", "A", "B"));
        svc.deleteTask("T1");
        assertFalse(svc.getAll().containsKey("T1"));
    }

    @Test
    void deleteTask_throwsWhenMissing() {
        TaskService svc = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> svc.deleteTask("NOPE"));
        assertThrows(IllegalArgumentException.class, () -> svc.deleteTask(null));
    }

    // update task fields 
    @Test
    void updates_applyWhenValid() {
        TaskService svc = new TaskService();
        svc.addTask(new Task("T1", "Old", "Old"));
        svc.updateName("T1", "New");
        svc.updateDescription("T1", "New description");
        assertEquals("New", svc.getAll().get("T1").getName());
        assertEquals("New description", svc.getAll().get("T1").getDescription());
    }

    @Test
    void updates_throwWhenMissingTask() {
        TaskService svc = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> svc.updateName("NOPE", "X"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateDescription("NOPE", "Y"));
    }

    @Test
    void updates_validateInputs() {
        TaskService svc = new TaskService();
        svc.addTask(new Task("T1", "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateName("T1", null));
        assertThrows(IllegalArgumentException.class,
            () -> svc.updateName("T1", "ThisNameIsWayTooLongForLimits")); // >20

        assertThrows(IllegalArgumentException.class, () -> svc.updateDescription("T1", null));
        assertThrows(IllegalArgumentException.class,
            () -> svc.updateDescription("T1", "123456789012345678901234567890123456789012345678901")); // 51
    }
}
