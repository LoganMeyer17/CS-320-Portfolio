/* Logan Meyer 10/11/2025 */
package taskservice;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

//manages collection of Task objects
public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    // Accessor
    public Map<String, Task> getAll() {
        return Collections.unmodifiableMap(tasks);
    }

    // add task
    public void addTask(Task task) {
        if (task == null) throw new IllegalArgumentException("task is null");
        String id = task.getTaskId();
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("duplicate id: " + id);
        }
        tasks.put(id, task);
    }

    // delete task
    public void deleteTask(String taskId) {
        if (taskId == null || !tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("no such task id: " + taskId);
        }
        tasks.remove(taskId);
    }

    // update task fields 
    public void updateName(String taskId, String name) {
        getExisting(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {
        getExisting(taskId).setDescription(description);
    }

    // throws error code if any are found
    private Task getExisting(String id) {
        Task t = tasks.get(id);
        if (t == null) throw new IllegalArgumentException("no such task id: " + id);
        return t;
    }
}
