/* Logan Meyer 10/11/2025 */
package taskservice;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TaskTest {
    // valid inputs should create new tasks
    @Test
    void constructor_validInputs_createsTask() {
        Task t = new Task("ID123", "Homework", "Finish the CS320 milestone");
        assertEquals("ID123", t.getTaskId());
        assertEquals("Homework", t.getName());
        assertEquals("Finish the CS320 milestone", t.getDescription());
    }

    // invalid inputs should throw illegal arguments exception
    @Test
    void constructor_invalidInputs_throw() {
        // id null or too long
        assertThrows(IllegalArgumentException.class,
            () -> new Task(null, "Homework", "Finish"));
        assertThrows(IllegalArgumentException.class,
            () -> new Task("01234567890", "Homework", "Finish")); // >10

        // name null or too long
        assertThrows(IllegalArgumentException.class,
            () -> new Task("ID", null, "Finish"));
        assertThrows(IllegalArgumentException.class,
            () -> new Task("ID", "ThisNameIsWayTooLongForLimits", "Finish")); // >20

        // description null or too long
        assertThrows(IllegalArgumentException.class,
            () -> new Task("ID", "Homework", null));
        assertThrows(IllegalArgumentException.class,
            () -> new Task("ID", "Homework",
                "This description is way too long and should not be allowed because it exceeds fifty characters total")); // >50
    }

    // updating fields should work when valid, and reject when invalid
    @Test
    void setters_validateAndUpdate() {
        Task t = new Task("ID", "OldName", "Old description");
        t.setName("NewName");
        t.setDescription("New description within fifty characters");

        assertEquals("NewName", t.getName());
        assertEquals("New description within fifty characters", t.getDescription());

        assertThrows(IllegalArgumentException.class, () -> t.setName(null));
        assertThrows(IllegalArgumentException.class,
            () -> t.setName("ThisNameIsWayTooLongForLimits")); // >20

        assertThrows(IllegalArgumentException.class, () -> t.setDescription(null));
        assertThrows(IllegalArgumentException.class,
            () -> t.setDescription("123456789012345678901234567890123456789012345678901")); // 51
    }
    @Test
    void equals_selfComparison_returnsTrue() {
        Task t = new Task("ID", "Name", "Desc");
        assertEquals(t, t);
    }

    @Test
    void equals_nullAndDifferentType_returnsFalse() {
        Task t = new Task("ID", "Name", "Desc");
        assertNotEquals(t, null);
        assertNotEquals(t, "not a task");
    }

    @Test
    void equals_sameId_returnsTrue() {
        Task a = new Task("X", "A", "Desc");
        Task b = new Task("X", "B", "Other");
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void equals_differentId_returnsFalse() {
        Task a = new Task("X", "A", "Desc");
        Task b = new Task("Y", "B", "Desc");
        assertNotEquals(a, b);
    }
    @Test
    void id_isNotUpdatable() {
        Task t = new Task("LOCKEDID", "Name", "Description");
        assertEquals("LOCKEDID", t.getTaskId());
    }
}
