/* Logan Meyer 10/11/2025 */
package taskservice;

import java.util.Objects;

// task class
public class Task {
    private final String taskId;        // not updatable, unique id (max 10 characters)
    private String name;                // required, max 20 characters
    private String description;         // required, max 50 characters

    // validates input and makes new tasks
    public Task(String taskId, String name, String description) {
        require(taskId != null && taskId.length() <= 10, "Invalid taskId");
        require(name != null && name.length() <= 20, "Invalid name");
        require(description != null && description.length() <= 50, "Invalid description");

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // helps validate
    private static void require(boolean cond, String message) {
        if (!cond) throw new IllegalArgumentException(message);
    }

    // getters
    public String getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getDescription() { return description; }

    // allows updates to fields
    public void setName(String name) {
        require(name != null && name.length() <= 20, "Invalid name");
        this.name = name;
    }

    public void setDescription(String description) {
        require(description != null && description.length() <= 50, "Invalid description");
        this.description = description;
    }

    // tasks are equal if they have the same task id
    @Override 
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Task)) return false;
        Task task = (Task) o;
        return Objects.equals(taskId, task.taskId);
    }

    @Override 
    public int hashCode() {
        return Objects.hash(taskId);
    }
}