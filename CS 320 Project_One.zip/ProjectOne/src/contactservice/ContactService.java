/* Logan Meyer 10/11/2025 */
package contactservice;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

//manages collection of Contact objects
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    // Accessor
    public Map<String, Contact> getAll() {
        return Collections.unmodifiableMap(contacts);
    }
// add contact
    public void addContact(Contact contact) {
        if (contact == null) throw new IllegalArgumentException("contact is null");
        String id = contact.getContactId();
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("duplicate id: " + id);
        }
        contacts.put(id, contact);
    }
// delete contact
    public void deleteContact(String contactId) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("no such contact id: " + contactId);
        }
        contacts.remove(contactId);
    }
// update contact fields 
    public void updateFirstName(String contactId, String firstName) {
        getExisting(contactId).setFirstName(firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        getExisting(contactId).setLastName(lastName);
    }

    public void updatePhone(String contactId, String phone) {
        getExisting(contactId).setPhone(phone);
    }

    public void updateAddress(String contactId, String address) {
        getExisting(contactId).setAddress(address);
    }
// throws error code if any are found
    private Contact getExisting(String id) {
        Contact c = contacts.get(id);
        if (c == null) throw new IllegalArgumentException("no such contact id: " + id);
        return c;
    }
}
