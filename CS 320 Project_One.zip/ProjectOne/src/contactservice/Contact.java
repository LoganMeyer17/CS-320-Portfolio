/* Logan Meyer 10/11/2025 */
package contactservice;

import java.util.Objects;

// contact class
public class Contact {
    private final String contactId;      // not updatable, unique id
    private String firstName;
    private String lastName;
    private String phone;                // exactly 10 digits
    private String address;

    // validates input and makes new contacts
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        require(contactId != null && contactId.length() <= 10, "Invalid contactId");
        require(firstName != null && firstName.length() <= 10, "Invalid firstName");
        require(lastName != null && lastName.length() <= 10, "Invalid lastName");
        require(phone != null && phone.matches("\\d{10}"), "Invalid phone");
        require(address != null && address.length() <= 30, "Invalid address");

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }
// helps validate
    private static void require(boolean cond, String message) {
        if (!cond) throw new IllegalArgumentException(message);
    }

    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName; }
    public String getPhone()     { return phone; }
    public String getAddress()   { return address; }

    //Allows updates to fields
    public void setFirstName(String firstName) {
        require(firstName != null && firstName.length() <= 10, "Invalid firstName");
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        require(lastName != null && lastName.length() <= 10, "Invalid lastName");
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        require(phone != null && phone.matches("\\d{10}"), "Invalid phone");
        this.phone = phone;
    }

    public void setAddress(String address) {
        require(address != null && address.length() <= 30, "Invalid address");
        this.address = address;
    }
// contacts are equal if they have the same contact id
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Contact)) return false;
        Contact contact = (Contact) o;
        return Objects.equals(contactId, contact.contactId);
    }

    @Override public int hashCode() {
        return Objects.hash(contactId);
    }
}
