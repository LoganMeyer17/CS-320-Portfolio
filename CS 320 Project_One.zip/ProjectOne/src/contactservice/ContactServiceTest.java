/* Logan Meyer 10/11/2025 */
package contactservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// unit tests for contactService class
class ContactServiceTest {
// creates a sample
    private Contact contact(String id) {
        return new Contact(id, "John", "Doe", "1234567890", "123 Main");
    }
// should add a new contact and reject duplicates
    @Test
    void addContact_enforcesUniqueId() {
        ContactService svc = new ContactService();
        svc.addContact(contact("A1"));
        assertEquals(1, svc.getAll().size());

        // duplicate id should throw
        assertThrows(IllegalArgumentException.class, () -> svc.addContact(contact("A1")));
    }
// should remove an existing contact or throw is id is missing
    @Test
    void deleteContact_removes_whenPresent_elseThrows() {
        ContactService svc = new ContactService();
        svc.addContact(contact("A1"));
        svc.deleteContact("A1");
        assertTrue(svc.getAll().isEmpty());

        // deleting again (or missing id) should throw
        assertThrows(IllegalArgumentException.class, () -> svc.deleteContact("A1"));
    }
// should update all fields of contact
    @Test
    void updateFields_modifiesExistingContact() {
        ContactService svc = new ContactService();
        svc.addContact(contact("A1"));

        svc.updateFirstName("A1", "Logan");
        svc.updateLastName("A1", "Meyer");
        svc.updatePhone("A1", "0987654321");
        svc.updateAddress("A1", "1019 Pro Ave");

        Contact c = svc.getAll().get("A1");
        assertEquals("Logan", c.getFirstName());
        assertEquals("Meyer", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("1019 Pro Ave", c.getAddress());
    }
// should throw for non-existing contact
    @Test
    void updates_missingId_throw() {
        ContactService svc = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> svc.updateFirstName("ZZ", "Logan"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateLastName("ZZ", "Meyer"));
        assertThrows(IllegalArgumentException.class, () -> svc.updatePhone("ZZ", "0987654321"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateAddress("ZZ", "1019 Pro Ave"));
    }
}
