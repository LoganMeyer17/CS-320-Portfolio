/* Logan Meyer 10/11/2025 */
package contactservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ContactTest {
// valid inputs should create new contacts
    @Test
    void constructor_validInputs_createsContact() {
        Contact c = new Contact("ID123", "John", "Doe", "1234567890", "123 Main Street");
        assertEquals("ID123", c.getContactId());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main Street", c.getAddress());
    }
// invalid inputs should throw illegal arguments exception
    @Test
    void constructor_invalidInputs_throw() {
        // id null or too long
        assertThrows(IllegalArgumentException.class,
            () -> new Contact(null, "John", "Doe", "1234567890", "addr"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("01234567890", "John", "Doe", "1234567890", "addr")); // >10

        // first/last null or too long
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", null, "Doe", "1234567890", "addr"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "FirstnameTooLong", "Doe", "1234567890", "addr"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "John", null, "1234567890", "addr"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "John", "LastnameTooLong", "1234567890", "addr"));

        // phone invalid
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "John", "Doe", null, "addr"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "John", "Doe", "12345", "addr"));      // not 10 digits
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "John", "Doe", "123456789A", "addr")); // non-digit

        // address null or too long
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "John", "Doe", "1234567890", null));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "John", "Doe", "1234567890",
                "This address is definitely longer than thirty characters in length"));
    }
// updating fields should work when valid, and reject is invalid
    @Test
    void setters_validateAndUpdate() {
        Contact c = new Contact("ID", "John", "Doe", "1234567890", "123 St");
        c.setFirstName("Jane");
        c.setLastName("Roe");
        c.setPhone("0987654321");
        c.setAddress("456 Ave");

        assertEquals("Jane", c.getFirstName());
        assertEquals("Roe", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("456 Ave", c.getAddress());

        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("bad"));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
    }
    @Test
    void boundaryValues_pass() {
        Contact c = new Contact("ABCDEFGHIJ", "FirstName1", "LastName10", "0123456789", "x".repeat(30));
        assertEquals(10, c.getContactId().length());
        assertEquals(10, c.getFirstName().length());
        assertEquals(10, c.getLastName().length());
        assertEquals(30, c.getAddress().length());
    }

    @Test
    void phone_withNonDigits_rejected() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "John", "Doe", "12345abcde", "addr"));
    }

    @Test
    void equalsAndHashCode_byId() {
        Contact a = new Contact("X", "A", "B", "1234567890", "addr");
        Contact b = new Contact("X", "C", "D", "1234567890", "addr");
        Contact c = new Contact("Y", "A", "B", "1234567890", "addr");
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
    }
    @Test
    void equals_selfComparison_returnsTrue() {
        Contact a = new Contact("Z", "A", "B", "1234567890", "addr");
        assertEquals(a, a);
    }
    @Test
    void equals_nullAndDifferentType_returnsFalse() {
        Contact a = new Contact("Z", "A", "B", "1234567890", "addr");
        assertNotEquals(a, null);
        assertNotEquals(a, "not a contact");
    }
    @Test
    void id_isNotUpdatable() {
        Contact c = new Contact("LOCKEDID", "John", "Doe", "1234567890", "addr");
        assertEquals("LOCKEDID", c.getContactId());
    }
}