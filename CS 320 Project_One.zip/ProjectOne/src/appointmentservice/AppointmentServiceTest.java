/* Logan Meyer 10/11/2025 */
package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentServiceTest {

    private AppointmentService service;

    private Date futureDate(int daysAhead) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, daysAhead);
        return c.getTime();
    }

    @BeforeEach
    void setup() {
        service = new AppointmentService();
    }

    @Test
    void addAppointmentSuccessfully() {
        Appointment a = new Appointment("A1", futureDate(2), "desc");
        service.addAppointment(a);
        assertEquals(1, service.size());
        assertNotNull(service.getAppointment("A1"));
    }

    @Test
    void addingDuplicateIdThrows() {
        Appointment a1 = new Appointment("A1", futureDate(2), "desc");
        Appointment a2 = new Appointment("A1", futureDate(3), "another");
        service.addAppointment(a1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(a2));
    }

    @Test
    void deleteExistingAppointment() {
        Appointment a = new Appointment("A2", futureDate(4), "desc");
        service.addAppointment(a);
        service.deleteAppointment("A2");
        assertEquals(0, service.size());
        assertNull(service.getAppointment("A2"));
    }

    @Test
    void deletingMissingAppointmentThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("NOPE"));
    }
    @Test
    void addingNullAppointmentThrows() {
        AppointmentService svc = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> svc.addAppointment(null));
    }

    @Test
    void deletingNullIdThrows() {
        AppointmentService svc = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> svc.deleteAppointment(null));
    }
}