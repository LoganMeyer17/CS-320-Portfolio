/* Logan Meyer 10/11/2025 */
package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate(int daysAhead) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, daysAhead);
        return c.getTime();
    }

    @Test
    void validAppointmentIsCreated() {
        Appointment a = new Appointment("A123", futureDate(3), "test practice");
        assertEquals("A123", a.getAppointmentId());
        assertNotNull(a.getAppointmentDate());
        assertEquals("test practice", a.getDescription());
    }

    @Test
    void idCannotBeNullOrLongerThan10() {
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment(null, futureDate(1), "desc"));
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("ABCDEFGHIJK", futureDate(1), "desc")); // 11 chars
    }

    @Test
    void dateCannotBeNullOrInPast() {
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("A1", null, "desc"));
        // Past date
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -1);
        Date past = c.getTime();
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("A1", past, "desc"));
    }

    @Test
    void descriptionCannotBeNullOrOver50Chars() {
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("A1", futureDate(1), null));

        String longDesc = "x".repeat(51);
        assertThrows(IllegalArgumentException.class,
            () -> new Appointment("A1", futureDate(1), longDesc));
    }

    @Test
    void idIsNotUpdatable() {
        Appointment a = new Appointment("LOCKEDID", futureDate(2), "desc");
        // there is no setter. just assert getter still returns the original
        assertEquals("LOCKEDID", a.getAppointmentId());
    }
    @Test
    void boundaryValues_pass_forIdAndDescription() {
        Appointment a = new Appointment("ABCDEFGHIJ", futureDate(1), "x".repeat(50));
        assertEquals(10, a.getAppointmentId().length());
        assertEquals(50, a.getDescription().length());
    }

    @Test
    void id_isNotUpdatable() {
        Appointment a = new Appointment("LOCKEDID", futureDate(1), "desc");
        assertEquals("LOCKEDID", a.getAppointmentId());
    }
     
}