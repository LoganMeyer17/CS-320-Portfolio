/* Logan Meyer 10/11/2025 */
package appointmentservice;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    // Add an appointment. ID must be unique.
    public void addAppointment(Appointment appt) {
        if (appt == null) {
            throw new IllegalArgumentException("Appointment cannot be null");
        }
        String id = appt.getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Duplicate appointment ID: " + id);
        }
        appointments.put(id, appt);
    }

    // Delete appointment by ID. Throw if it doesn't exist.
    public void deleteAppointment(String id) {
        if (id == null) {
            throw new IllegalArgumentException("ID cannot be null");
        }
        if (!appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment ID not found: " + id);
        }
        appointments.remove(id);
    }

    public Appointment getAppointment(String id) {
        return appointments.get(id);
    }

    public int size() {
        return appointments.size();
    }
}
